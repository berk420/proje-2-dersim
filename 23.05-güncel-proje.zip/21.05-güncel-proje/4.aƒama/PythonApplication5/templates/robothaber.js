var options = {
	type:"basic",
	title:"extensin title",
	message:"ex message",
	iconUrl:"icon.png",
	imageUrl:"icon.png"

};

chrome.notifications.create(options,callback);

console.log("pop up done");

function callback(){
	console.log("pop up oldu");
}