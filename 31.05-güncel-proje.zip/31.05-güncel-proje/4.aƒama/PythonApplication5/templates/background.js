window.addEventListener('load',()=>{
	if (!window.Notification) return;

})


const sendNotification =(permission)=>{
	let notification =new Notification ('yeni bild',{
		body:'ilOKFHGAŞKJFVNAŞKDFJNBAŞKDJFNVAGDKFVNADŞFKVJNADKFŞJVANDKFJVBN',
		icon:'icon.png'
	})
    notification.onclick =() =>{
    	window.location.href="https://www.google.com/"
    }
    console.log(notification);
}

	
const button =document.getElementById('button')
button.addEventListener('click',()=>{
	Notification
	.requestPermission()
	.then(sendNotification)
})